<?php
session_start();
include 'db_connect.php';

if(isset($_POST['login'])){

$username=$_POST['username'];
$password=$_POST['password'];

$sql="SELECT * FROM users WHERE username='$username' AND password='$password'";
$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
$_SESSION['user']=$username;
header("Location:dashboard.php");
}else{
echo "Login Failed";
}
}
?>

<form method="POST">
<h2>Login</h2>

Username<br>
<input type="text" name="username"><br><br>

Password<br>
<input type="password" name="password"><br><br>

<button name="login">Login</button>

</form>