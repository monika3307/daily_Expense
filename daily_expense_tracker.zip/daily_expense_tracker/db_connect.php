<?php
$conn = mysqli_connect("localhost","root","","expense_tracker");

if(!$conn){
    echo "Database connection failed";
}
?>