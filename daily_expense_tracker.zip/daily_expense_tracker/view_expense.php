<?php
include 'db_connect.php';

$sql = "SELECT * FROM expenses";
$result = mysqli_query($conn,$sql);

$total = 0;
?>

<!DOCTYPE html>
<html>
<head>
<title>View Expenses</title>
</head>

<body>

<h2>Expenses List</h2>

<table border="1" cellpadding="10">

<tr>
<th>ID</th>
<th>Title</th>
<th>Amount</th>
<th>Category</th>
<th>Date</th>
<th>Description</th>
<th>Action</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
$total += $row['amount'];
?>

<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['title']; ?></td>
<td><?php echo $row['amount']; ?></td>
<td><?php echo $row['category']; ?></td>
<td><?php echo $row['date']; ?></td>
<td><?php echo $row['description']; ?></td>

<td>
<a href="edit_expense.php?id=<?php echo $row['id']; ?>">Edit</a> |
<a href="delete_expense.php?id=<?php echo $row['id']; ?>">Delete</a>
</td>

</tr>

<?php
}
?>

</table>

<h3>Total Expense: <?php echo $total; ?></h3>

</body>
</html>