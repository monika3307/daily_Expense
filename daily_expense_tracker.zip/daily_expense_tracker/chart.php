<?php
include 'db_connect.php';

$sql="SELECT MONTH(date) as month, SUM(amount) as total 
FROM expenses GROUP BY MONTH(date)";
$result=mysqli_query($conn,$sql);

$months=[];
$totals=[];

while($row=mysqli_fetch_assoc($result)){
$months[]=$row['month'];
$totals[]=$row['total'];
}
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<canvas id="myChart"></canvas>

<script>

var ctx=document.getElementById('myChart').getContext('2d');

var chart=new Chart(ctx,{
type:'bar',

data:{
labels: <?php echo json_encode($months); ?>,

datasets:[{
label:'Monthly Expenses',
data: <?php echo json_encode($totals); ?>,
backgroundColor:'blue'
}]
}

});

</script>