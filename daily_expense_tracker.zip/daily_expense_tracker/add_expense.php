<?php
include 'db_connect.php';

if(isset($_POST['submit'])){

$title = $_POST['title'];
$amount = $_POST['amount'];
$category = $_POST['category'];
$date = $_POST['date'];
$description = $_POST['description'];

$sql = "INSERT INTO expenses(title,amount,category,date,description)
VALUES('$title','$amount','$category','$date','$description')";

mysqli_query($conn,$sql);

echo "Expense Added Successfully";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Expense</title>
</head>

<body>

<h2>Add Daily Expense</h2>

<form method="POST">

Expense Title:<br>
<input type="text" name="title" required><br><br>

Amount:<br>
<input type="number" name="amount" required><br><br>

Category:<br>
<input type="text" name="category"><br><br>

Date:<br>
<input type="date" name="date"><br><br>

Description:<br>
<textarea name="description"></textarea><br><br>

<button type="submit" name="submit">Add Expense</button>

</form>

</body>
</html>