<?php
session_start();
if(!isset($_SESSION['user'])){
header("Location:login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Expense Tracker Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="sidebar">

<h2>Expense Tracker</h2>

<a href="dashboard.php">Dashboard</a>
<a href="add_expense.php">Add Expense</a>
<a href="view_expense.php">View Expenses</a>
<a href="chart.php">Monthly Chart</a>
<a href="logout.php">Logout</a>

</div>

<div class="main">

<h1>Dashboard</h1>

<div class="cards">

<div class="card orange">
<h3>Total Expenses</h3>
<p>₹500</p>
</div>

<div class="card blue">
<h3>Total Entries</h3>
<p>3</p>
</div>

<div class="card green">
<h3>Monthly Report</h3>
<p>April</p>
</div>

</div>

</div>

</body>
</html>