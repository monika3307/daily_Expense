<?php
include 'db_connect.php';

$id = $_GET['id'];

$result = mysqli_query($conn,"SELECT * FROM expenses WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update'])){

$title=$_POST['title'];
$amount=$_POST['amount'];
$category=$_POST['category'];
$date=$_POST['date'];
$description=$_POST['description'];

mysqli_query($conn,"UPDATE expenses SET
title='$title',
amount='$amount',
category='$category',
date='$date',
description='$description'
WHERE id=$id");

header("Location:view_expense.php");
}
?>

<form method="POST">

Title
<input type="text" name="title" value="<?php echo $row['title']; ?>"><br>

Amount
<input type="number" name="amount" value="<?php echo $row['amount']; ?>"><br>

Category
<input type="text" name="category" value="<?php echo $row['category']; ?>"><br>

Date
<input type="date" name="date" value="<?php echo $row['date']; ?>"><br>

Description
<textarea name="description"><?php echo $row['description']; ?></textarea><br>

<button name="update">Update Expense</button>

</form>